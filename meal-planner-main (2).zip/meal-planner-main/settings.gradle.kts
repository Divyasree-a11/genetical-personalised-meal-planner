
rootProject.name = "meal-planner"

include(":core")
include(":cli")
include(":web")